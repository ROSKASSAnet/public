<?php

$auth = [
    'shop_id' => '067D93123FF123F57CC9E8E8F3F650787F',
    'secret_key' => 'IJUN%TYU*K'
];

$data = array(
    'shop_id'=>$auth['shop_id'],
    'amount'=>100,
    'currency'=>'RUB',
    'order_id'=>'123',
);

ksort($data);
$str = http_build_query($data);
$sign = md5($str . $auth['secret_key']);

?>

<form action="https://pay.roskassa.net/" target="_blank" method="post">
    <input type="hidden" name="shop_id" value="<?=$data['shop_id']?>">
    <input type="hidden" name="amount" value="<?=$data['amount']?>">
    <input type="hidden" name="order_id" value="<?=$data['order_id']?>">
    <input type="hidden" name="currency" value="<?=$data['currency']?>">

    <input type="hidden" name="receipt[items][0][name]" value="Пример услуги">
    <input type="hidden" name="receipt[items][0][count]" value="1">
    <input type="hidden" name="receipt[items][0][price]" value="100">

    <input type="hidden" name="lang" value="ru">

    <input type="hidden" name="sign" value="<?=$sign?>">
    <input type="submit" value="Оплатить">
</form>
