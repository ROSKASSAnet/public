<?php

class Roskassa {

    private string $apiUrl = 'https://api.roskassa.net/';
    private array $authData;

    function __construct($shopId, $apiKey) {

        $this->authData = [
            'shopId'=>$shopId,
            'apiKey'=>$apiKey
        ];

    }

    /**
     * @param string $currency
     * @param float $amount
     * @param string $orderId
     * @param int $paymentSystem
     * @param array $fields
     * @param array $receipt
     * @return array
     * @throws Exception
     */
    public function createOrder($currency, $amount, $orderId, $paymentSystem, $fields, $receipt = []): array
    {
        $data = [
            'currency' => $currency,
            'amount' => $amount,
            'order_id' => $orderId,
            'payment_system' => $paymentSystem,
            'fields' => $fields,
            'receipt' => $receipt
        ];

        try {
            $res = $this->makeRequest('createOrder', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @param int $orderId
     * @return array
     * @throws Exception
     */
    public function orderByOrderId($orderId): array
    {
        $data = [
            'order_id' => $orderId
        ];

        try {
            $res = $this->makeRequest('order', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @param string $paymentId
     * @return array
     * @throws Exception
     */
    public function orderByPaymentId($paymentId): array
    {
        $data = [
            'payment_id' => $paymentId
        ];

        try {
            $res = $this->makeRequest('order', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @param int $status
     * @param int $page
     * @return array
     * @throws Exception
     */
    public function orders($status = false, $page = 0): array
    {
        $data = [
            'status' => $status,
            'page' => $page,
        ];

        try {
            $res = $this->makeRequest('orders', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @param string $currency
     * @param float $amount
     * @param string $account
     * @param int $paymentSystem
     * @param string $paymentId
     * @return array
     * @throws Exception
     */
    public function createWithdrawal($currency, $amount, $account, $paymentSystem, $paymentId = ''): array
    {
        $data = [
            'currency' => $currency,
            'amount' => $amount,
            'account' => $account,
            'payment_system'=>$paymentSystem,
            'payment_id' => $paymentId,
        ];

        try {
            $res = $this->makeRequest('createWithdrawal', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }


    /**
     * @param string $orderId
     * @return array
     * @throws Exception
     */
    public function withdrawalByOrderId($orderId): array
    {
        $data = [
            'order_id' => $orderId
        ];

        try {
            $res = $this->makeRequest('withdrawal', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @param string $paymentId
     * @return array
     * @throws Exception
     */
    public function withdrawalByPaymentId($paymentId): array
    {
        $data = [
            'payment_id' => $paymentId
        ];

        try {
            $res = $this->makeRequest('withdrawal', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }


    /**
     * @param int $status
     * @param int $page
     * @return array
     * @throws Exception
     */
    public function withdrawals($status = false, $page = 0): array
    {
        $data = [
            'page' => $page,
        ];

        if ($status) $data['status'] = $status;

        try {
            $res = $this->makeRequest('withdrawals', $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @return array
     * @throws Exception
     */
    public function shops(): array
    {
        try {
            $res = $this->makeRequest('shops', []);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @return array
     * @throws Exception
     */
    public function balance(): array
    {
        try {
            $res = $this->makeRequest('balance', []);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $res;
    }

    /**
     * @param $method
     * @param array $data
     * @return array
     * @throws Exception
     */
    private function makeRequest($method, $data = []): array
    {

        $data['shop_id'] = $this->authData['shopId'];
        $data['nonce'] = time();

        $body = json_encode($data);
        $sign = hash_hmac('sha256', $body, $this->authData['apiKey']);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->apiUrl . $method . '/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => array(
                "Authorization: Bearer $sign",
                "Content-Type: application/json"
            ),
        ));

        $response = curl_exec($curl);

        if($curlError = curl_errno($curl)){
            throw new Exception('Curl error '.curl_error($curl).' '.$curlError);
        }

        curl_close($curl);

        $data = json_decode($response, true);

        if (!is_array($data)) {
            throw new Exception('Wrong answer from server');
        }

        if ($data['type'] == 'error') throw new Exception("Error ".$data['desc']);

        return $data;

    }
}