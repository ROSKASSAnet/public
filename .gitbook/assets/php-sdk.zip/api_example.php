<?php
ini_set("display_errors","1");
ini_set("display_startup_errors","1");
ini_set('error_reporting', E_ALL);

$auth = [
    'shop_id' => '067D93123FF123F57CC9E8E8F3F650787F',
    'api_key' => 'rF^BF&*YUJiopgW'
];

require __DIR__ . '/Roskassa.php';

$Roskassa = new Roskassa($auth['shop_id'], $auth['api_key']);

/* Создание заказа */
$data = [
    'currency' => 'RUB', //Валюта платежа
    'amount' => 1200, //Сумма оплаты
    'orderId' => 'Тестовый платеж', //Номер заказа или описание платежа
    'paymentSystem' => 5, //ID платежной системы
    'fields' => [ //информация о покупателе
        'email' => 'test@test-email.ru',
    ],
    'receipt' => [ //Данные для чека, если включено
        'items' => [
            [
                'name' => 'test product 1',
                'count' => 1,
                'price' => 600
            ],
            [
                'name' => 'test product 2',
                'count' => 1,
                'price' => 600
            ]
        ],
    ]
];


//$res = [];
//try {
//    $res = $Roskassa->createOrder($data['currency'], $data['amount'], $data['orderId'], $data['paymentSystem'], $data['fields'], $data['receipt']);
//} catch (Exception $e) {
//    echo "Create order error " . $e->getMessage();
//}
//print_r($res);



/* Поиск заказа по номеру Roskassa */

//$res = [];
//try {
//    $res = $Roskassa->orderByOrderId(1661203);
//} catch (Exception $e) {
//    echo "Search order by ID error " . $e->getMessage();
//}
//print_r($res);

/* или по номеру магазина */

//$res = [];
//try {
//    $res = $Roskassa->orderByPaymentId('Тестовый платеж');
//} catch (Exception $e) {
//    echo "Search order by Payment ID error " . $e->getMessage();
//}
//print_r($res);


/* Список заказов */
$data = [
    'status'=>1, //Фильтровать по статусу. 0 - не оплачен, 1 - оплачен
    'page'=>0
];

//$res = [];
//try {
//    $res = $Roskassa->orders($data['status'], $data['page']);
//} catch (Exception $e) {
//    echo "List orders error " . $e->getMessage();
//}
//print_r($res);

/* Создать заявку на вывод */
$data = [
    'currency'=>'RUB',
    'amount'=>100,
    'account'=>456789098765, //Номер счета или кошелька для вывода
    'paymentSystem'=>5, //ID платежной системы
    'paymentId'=>'Тестовая выплата'
];


//$res = [];
//try {
//    $res = $Roskassa->createWithdrawal($data['currency'], $data['amount'], $data['account'], $data['paymentId']);
//} catch (Exception $e) {
//    echo "Create withdrawal error " . $e->getMessage();
//}
//print_r($res);



/* Поиск выплаты по номеру Roskassa */

//$res = [];
//try {
//    $res = $Roskassa->withdrawalByOrderId('25706b6sd3210e8148d06fd5a7081c');
//} catch (Exception $e) {
//    echo "Search withdrawal by ID error " . $e->getMessage();
//}
//print_r($res);


/* или по номеру магазина */

//$res = [];
//try {
//    $res = $Roskassa->withdrawalByPaymentId('Тестовая выплата');
//} catch (Exception $e) {
//    echo "Search withdrawal by Payment ID error " . $e->getMessage();
//}
//print_r($res);


/* Список выплат */
$data = [
    'status'=>null, //Фильтровать по статусу. 0 - новая, 1 - выплачена, 9 - отменена
    'page'=>0
];

//$res = [];
//try {
//    $res = $Roskassa->withdrawals($data['status'], $data['page']);
//} catch (Exception $e) {
//    echo "List withdrawals error " . $e->getMessage();
//}
//print_r($res);


/* Список магазинов */

//$res = [];
//try {
//    $res = $Roskassa->shops();
//} catch (Exception $e) {
//    echo "List shops error " . $e->getMessage();
//}
//print_r($res);


/* Баланс */

//$res = [];
//try {
//    $res = $Roskassa->balance();
//} catch (Exception $e) {
//    echo "List shops error " . $e->getMessage();
//}
//print_r($res);