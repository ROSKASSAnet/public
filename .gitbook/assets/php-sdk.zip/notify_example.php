<?php

$auth = [
    'shop_id' => '067D93123FF123F57CC9E8E8F3F650787F',
    'secret_key' => 'IJUN%TYU*K'
];


$data = $_POST;
unset($data['sign']);
ksort($data);
$str = http_build_query($data);
$sign = md5($str . $auth['secret_key']);

/* Проверяем подпись запроса */
if ($sign != $_POST['sign']) {
    die("Wrong signature");
}

/*
 * Далее необходимо реализовать дополнительные проверки, которые необходимы в Вашем случае
 * статус заказа, сумму оплаты и прочее
 */

